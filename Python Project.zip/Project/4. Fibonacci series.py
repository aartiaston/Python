num = int(input("Enter a number: "))

a = 0
b = 1

if num == 0:
    print("Fibonacci series is: 0")

elif num == 1:
    print("Fibonacci series is: 0 1")

else:
    print("Fibonacci series:")

    print(a, b, end=" ")

    for i in range(2, num):
        c = a + b
        print(c, end=" ")

        a = b
        b = c



        