text=input("enter the number or words:")
result= " "
for ch in text:
    if ch.isupper():
        result+= ch.lower()
    else:
        result+=ch.upper()
print("After swapped:", result)            
    