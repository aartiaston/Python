import random
number = random.randint (0,50)
print ('Number:', number)

chances = 3
message = 'GAME OVER'

while chances > 0 :
    print (chances, 'attempt left.')
    chances -= 1
    user_input = int(input ('Enter Number:'))

    if user_input == number :
        message = 'YOU WON!'
        break
    else:
        print ('TRY AGAIN')
        continue
    print(message)