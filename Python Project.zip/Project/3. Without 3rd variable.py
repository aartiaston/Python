x = int(input('Enter number 1 :'))
y = int(input('Enter number 2 :'))

x, y = y, x

print ('After swapping \nNumber 1 :', x)
print ('Number 2 :', y)